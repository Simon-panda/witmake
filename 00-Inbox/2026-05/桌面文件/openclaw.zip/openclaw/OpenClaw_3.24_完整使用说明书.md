# OpenClaw 3.24 完整使用说明书

> **版本：** OpenClaw 2026.3.24 (cff6dc9)  
> **发布日期：** 2026年3月24日  
> **文档类型：** 完整使用指南  
> **适用对象：** 初学者至高级用户  
> **文档状态：** 持续更新中

---

## 📋 目录

### 第一部分：入门指南
1. [OpenClaw 简介](#1-openclaw-简介)
2. [系统要求与安装](#2-系统要求与安装)
3. [首次配置与设置](#3-首次配置与设置)
4. [基本概念理解](#4-基本概念理解)

### 第二部分：核心功能详解
5. [网关(Gateway)管理](#5-网关gateway管理)
6. [代理(Agent)系统](#6-代理agent系统)
7. [会话(Session)管理](#7-会话session管理)
8. [技能(Skills)系统](#8-技能skills系统)
9. [工具(Tools)使用指南](#9-工具tools使用指南)

### 第三部分：通信渠道集成
10. [渠道(Channels)配置](#10-渠道channels配置)
11. [消息发送与管理](#11-消息发送与管理)
12. [群组与联系人管理](#12-群组与联系人管理)

### 第四部分：高级功能
13. [定时任务(Cron)系统](#13-定时任务cron系统)
14. [节点(Nodes)管理](#14-节点nodes管理)
15. [浏览器控制](#15-浏览器控制)
16. [安全与权限管理](#16-安全与权限管理)
17. [备份与恢复](#17-备份与恢复)

### 第五部分：开发与扩展
18. [技能开发指南](#18-技能开发指南)
19. [插件开发](#19-插件开发)
20. [API与集成](#20-api与集成)

### 第六部分：故障排除
21. [常见问题解答](#21-常见问题解答)
22. [错误代码解析](#22-错误代码解析)
23. [性能优化](#23-性能优化)

### 附录
- [A. 命令行参考](#a-命令行参考)
- [B. 配置文件详解](#b-配置文件详解)
- [C. 快捷键速查表](#c-快捷键速查表)
- [D. 更新日志](#d-更新日志)

---

## 1. OpenClaw 简介

### 1.1 什么是 OpenClaw？
OpenClaw 是一个开源的、模块化的 AI 代理平台，允许用户通过统一的接口与多个 AI 模型交互，并集成各种外部服务和工具。

### 1.2 核心特性
- **多模型支持**：支持 DeepSeek、OpenAI、Google、Anthropic 等多种 AI 模型
- **工具集成**：内置文件操作、网络搜索、浏览器控制等 100+ 工具
- **渠道集成**：支持 Telegram、Discord、WhatsApp、飞书等通信平台
- **技能系统**：模块化的技能扩展机制
- **定时任务**：内置 Cron 定时任务系统
- **安全控制**：细粒度的权限管理和安全审计

### 1.3 版本 3.24 新特性
- 性能优化和稳定性提升
- 新增工具和技能支持
- 安全增强功能
- 用户体验改进

---

## 2. 系统要求与安装

### 2.1 系统要求
#### 最低配置
- **操作系统**：macOS 10.15+、Ubuntu 20.04+、Windows 10+
- **内存**：4GB RAM
- **存储**：2GB 可用空间
- **网络**：稳定的互联网连接

#### 推荐配置
- **操作系统**：macOS 12+、Ubuntu 22.04+
- **内存**：8GB RAM 或更高
- **存储**：10GB 可用空间
- **处理器**：多核 CPU

### 2.2 安装方法

#### 方法一：npm 安装（推荐）
```bash
# 全局安装 OpenClaw
npm install -g openclaw

# 验证安装
openclaw --version
```

#### 方法二：从源码安装
```bash
# 克隆仓库
git clone https://github.com/openclaw/openclaw.git
cd openclaw

# 安装依赖
npm install

# 构建项目
npm run build

# 链接到全局
npm link
```

#### 方法三：Docker 安装
```bash
# 拉取 Docker 镜像
docker pull openclaw/openclaw:latest

# 运行容器
docker run -d --name openclaw \
  -p 18789:18789 \
  -v ~/.openclaw:/root/.openclaw \
  openclaw/openclaw:latest
```

### 2.3 安装验证
安装完成后，运行以下命令验证安装：

```bash
# 检查版本
openclaw --version

# 查看帮助
openclaw help

# 运行状态检查
openclaw status
```

如果看到版本信息和状态报告，说明安装成功。

---

## 3. 首次配置与设置

### 3.1 初始化配置
首次运行 OpenClaw 需要进行基本配置：

```bash
# 运行初始化向导
openclaw setup

# 或使用交互式配置
openclaw configure
```

### 3.2 配置文件结构
OpenClaw 的配置文件位于 `~/.openclaw/config.json`，主要包含以下部分：

```json
{
  "gateway": {
    "bind": "127.0.0.1:18789",
    "auth": {
      "token": "your-secret-token"
    }
  },
  "agents": {
    "defaults": {
      "model": "deepseek/deepseek-chat"
    }
  },
  "channels": {
    "telegram": {
      "enabled": false,
      "botToken": ""
    },
    "discord": {
      "enabled": false,
      "botToken": ""
    }
  }
}
```

### 3.3 基本配置步骤

#### 步骤 1：设置网关
```bash
# 查看当前网关配置
openclaw config get gateway

# 设置网关绑定地址
openclaw config set gateway.bind "0.0.0.0:18789"

# 生成安全令牌
openclaw config set gateway.auth.token $(openssl rand -hex 32)
```

#### 步骤 2：配置默认 AI 模型
```bash
# 查看可用模型
openclaw models list

# 设置默认模型
openclaw config set agents.defaults.model "deepseek/deepseek-chat"
```

#### 步骤 3：启用控制界面
```bash
# 启用控制 UI
openclaw config set gateway.controlUi.enabled true

# 设置允许的源
openclaw config set gateway.controlUi.allowedOrigins '["http://localhost:3000"]'
```

### 3.4 启动网关服务
```bash
# 启动网关（前台运行）
openclaw gateway

# 或作为服务启动
openclaw gateway start

# 检查服务状态
openclaw gateway status
```

---

## 4. 基本概念理解

### 4.1 核心组件

#### 网关 (Gateway)
- **作用**：OpenClaw 的核心服务，处理所有请求和响应
- **功能**：路由消息、管理会话、协调工具调用
- **访问**：通过 WebSocket 在 `ws://localhost:18789` 访问

#### 代理 (Agent)
- **作用**：AI 代理实例，处理用户请求
- **类型**：主代理、子代理、专用代理
- **配置**：每个代理可以有不同的模型和技能

#### 会话 (Session)
- **作用**：用户与代理的对话上下文
- **特性**：保持对话历史、工具调用记录
- **管理**：可以暂停、恢复、导出会话

#### 技能 (Skill)
- **作用**：扩展代理能力的模块
- **类型**：内置技能、自定义技能、第三方技能
- **安装**：通过技能市场或手动安装

#### 工具 (Tool)
- **作用**：代理可以调用的具体功能
- **示例**：文件读写、网络搜索、浏览器控制
- **权限**：每个工具都有相应的权限控制

### 4.2 工作流程
```
用户请求 → 网关接收 → 路由到代理 → 代理处理 → 调用工具 → 返回结果 → 发送给用户
```

### 4.3 数据存储结构
```
~/.openclaw/
├── config.json          # 主配置文件
├── agents/              # 代理配置
│   └── main/           # 主代理目录
├── sessions/           # 会话存储
├── skills/             # 技能目录
├── workspace/          # 工作空间
└── logs/               # 日志文件
```

---

## 5. 网关(Gateway)管理

### 5.1 网关服务管理

#### 启动和停止
```bash
# 启动网关服务
openclaw gateway start

# 停止网关服务
openclaw gateway stop

# 重启网关服务
openclaw gateway restart

# 查看服务状态
openclaw gateway status
```

#### 前台运行（调试模式）
```bash
# 前台运行网关
openclaw gateway

# 带详细日志
openclaw gateway --verbose

# 指定端口
openclaw gateway --port 18888
```

### 5.2 网关配置

#### 查看当前配置
```bash
# 查看完整配置
openclaw config get

# 查看网关配置
openclaw config get gateway

# 查看特定配置项
openclaw config get gateway.bind
```

#### 修改配置
```bash
# 设置绑定地址
openclaw config set gateway.bind "0.0.0.0:18789"

# 设置认证令牌
openclaw config set gateway.auth.token "new-secret-token"

# 启用控制界面
openclaw config set gateway.controlUi.enabled true
```

#### 配置验证
```bash
# 验证配置文件
openclaw config validate

# 应用配置更改
openclaw gateway restart
```

### 5.3 网关监控

#### 查看网关状态
```bash
# 查看网关运行状态
openclaw gateway status

# 查看网关健康状态
openclaw health

# 查看网关日志
openclaw logs
```

#### 性能监控
```bash
# 查看会话统计
openclaw sessions list

# 查看内存使用
openclaw gateway stats

# 查看连接数
openclaw gateway connections
```

### 5.4 网关安全

#### 安全配置
```bash
# 设置访问控制
openclaw config set gateway.auth.rateLimit.maxAttempts 10
openclaw config set gateway.auth.rateLimit.windowMs 60000

# 启用 HTTPS（如果配置了证书）
openclaw config set gateway.tls.enabled true
openclaw config set gateway.tls.certPath "/path/to/cert.pem"
openclaw config set gateway.tls.keyPath "/path/to/key.pem"
```

#### 安全审计
```bash
# 运行安全审计
openclaw security audit

# 深度安全审计
openclaw security audit --deep

# 修复安全问题
openclaw security fix
```

---

## 6. 代理(Agent)系统

### 6.1 代理类型

#### 主代理 (Main Agent)
- **作用**：默认代理，处理大多数请求
- **位置**：`~/.openclaw/agents/main/`
- **配置**：通过 `AGENTS.md` 和 `SOUL.md` 自定义

#### 子代理 (Sub-agent)
- **作用**：临时创建的代理实例
- **用途**：处理特定任务或并行处理
- **生命周期**：任务完成后自动销毁

#### 专用代理 (Specialized Agent)
- **作用**：为特定用途配置的代理
- **示例**：代码编写代理、数据分析代理
- **配置**：独立的配置文件和技能集

### 6.2 代理配置

#### 查看代理配置
```bash
# 列出所有代理
openclaw agents list

# 查看代理详情
openclaw agents describe main

# 查看代理工作空间
ls -la ~/.openclaw/agents/main/
```

#### 代理配置文件
每个代理目录包含以下文件：
```
main/
├── AGENTS.md          # 代理工作空间说明
├── SOUL.md           # 代理个性定义
├── USER.md           # 用户信息
├── TOOLS.md          # 工具配置
├── HEARTBEAT.md      # 心跳任务
├── MEMORY.md         # 长期记忆
└── memory/           # 日常记忆目录
```

#### 自定义代理个性
编辑 `SOUL.md` 文件定义代理个性：
```markdown
# SOUL.md - 代理个性定义

## 核心定位
专业严谨、数据驱动的智能助手

## 核心职责
- 提供准确的信息和建议
- 协助完成各种任务
- 保持专业和友好的态度

## 沟通风格
- 正式但友好
- 清晰简洁
- 提供具体建议
```

### 6.3 代理操作

#### 运行代理任务
```bash
# 直接运行代理任务
openclaw agent --message "你好，请介绍一下自己"

# 指定目标发送
openclaw agent --to "+1234567890" --message "提醒：会议即将开始"

# 使用特定模型
openclaw agent --model "openai/gpt-4" --message "分析这个数据"
```

#### 创建子代理
```bash
# 创建临时子代理
openclaw agents create temp-agent --model "deepseek/deepseek-chat"

# 运行子代理任务
openclaw agents run temp-agent --message "处理这个任务"

# 删除子代理
openclaw agents delete temp-agent
```

### 6.4 代理技能管理

#### 查看可用技能
```bash
# 列出所有技能
openclaw skills list

# 查看技能详情
openclaw skills describe weather

# 搜索技能
openclaw skills search "文档"
```

#### 安装技能
```bash
# 从技能市场安装
openclaw skills install weather

# 从本地安装
openclaw skills install /path/to/skill

# 从 Git 仓库安装
openclaw skills install https://github.com/user/skill-repo.git
```

#### 更新和卸载技能
```bash
# 更新技能
openclaw skills update weather

# 更新所有技能
openclaw skills update --all

# 卸载技能
openclaw skills uninstall weather
```

---

## 7. 会话(Session)管理

### 7.1 会话概念

#### 什么是会话？
- **定义**：用户与代理的一次完整交互过程
- **内容**：包含对话历史、工具调用记录、上下文信息
- **存储**：自动保存，可以恢复和导出

#### 会话类型
- **主会话**：与主代理的持续对话
- **临时会话**：一次性任务会话
- **持久会话**：长期保持的专用会话

### 7.2 会话操作

#### 查看会话列表
```bash
# 列出所有会话
openclaw sessions list

# 查看活跃会话
openclaw sessions list --active

# 查看会话详情
openclaw sessions describe <session-key>
```

#### 会话统计信息
```bash
# 查看会话统计
openclaw sessions stats

# 查看会话使用情况
openclaw sessions usage

# 查看会话历史
openclaw sessions history <session-key>
```

### 7.3 会话控制

#### 创建新会话
```bash
# 创建命名会话
openclaw sessions create project-analysis

# 创建带标签的会话
openclaw sessions create --label "数据分析任务" data-task

# 创建特定类型会话
openclaw sessions create --type "persistent" long-term
```

#### 管理会话状态
```bash
# 暂停会话
openclaw sessions pause <session-key>

# 恢复会话
openclaw sessions resume <session-key>

# 结束会话
openclaw sessions end <session-key>

# 删除会话
openclaw sessions delete <session-key>
```

### 7.4 会话数据

#### 导出会话数据
```bash
# 导出会话为 JSON
openclaw sessions export <session-key> --format json

# 导出会话为 Markdown
openclaw sessions export <session-key> --format markdown

# 导出到文件
openclaw sessions export <session-key> --output session-backup.json
```

#### 导入会话数据
```bash
# 从文件导入会话
openclaw sessions import --file session-backup.json

# 从 JSON 导入
openclaw sessions import --json '{"messages": [...]}'
```

#### 会话清理
```bash
# 清理过期会话
openclaw sessions cleanup

# 清理特定时间的会话
openclaw sessions cleanup --older-than 7d

# 清理前确认
openclaw sessions cleanup --dry-run
```

---

## 8. 技能(Skills)系统

### 8.1 技能基础

#### 技能结构
每个技能包含以下文件：
```
skill-name/
├── SKILL.md          # 技能说明文档
├── package.json      # 技能配置
├── src/              # 源代码
├── tools/            # 工具定义
└── references/       # 参考文档
```

#### 技能类型
1. **工具技能**：提供新的工具功能
2. **集成技能**：集成第三方服务
3. **处理技能**：数据转换和处理4. **自动化技能**：自动执行重复任务

### 8.2 内置技能介绍

#### 天气技能 (weather)
```bash
# 使用天气技能
openclaw skills run weather --location "北京" --days 3

# 获取当前天气
openclaw skills run weather --current --location "上海"

# 详细天气预报
openclaw skills run weather --detailed --location "广州"
```

#### 文档处理技能 (feishu-doc)
```bash
# 读取飞书文档
openclaw skills run feishu-doc --url "https://example.feishu.cn/docx/..."

# 创建新文档
openclaw skills run feishu-doc --create --title "项目报告"

# 更新文档内容
openclaw skills run feishu-doc --update --url "..." --content "# 更新内容"
```

#### 表格处理技能 (feishu-bitables)
```bash
# 读取表格数据
openclaw skills run feishu-bitables --url "https://example.feishu.cn/base/..."

# 添加新记录
openclaw skills run feishu-bitables --add-record --table "任务表" --data '{"任务": "测试", "状态": "进行中"}'

# 更新记录
openclaw skills run feishu-bitables --update-record --record-id "rec123" --data '{"状态": "完成"}'
```

### 8.3 技能管理命令

#### 技能搜索和发现
```bash
# 搜索技能
openclaw skills search "天气"

# 查看技能市场
openclaw skills marketplace

# 查看热门技能
openclaw skills popular

# 查看技能分类
openclaw skills categories
```

#### 技能安装和配置
```bash
# 安装技能（详细步骤）
openclaw skills install weather --version "1.2.0"

# 配置技能参数
openclaw skills config weather set api_key "your-api-key"

# 查看技能配置
openclaw skills config weather get

# 重置技能配置
openclaw skills config weather reset
```

#### 技能更新和维护
```bash
# 检查技能更新
openclaw skills check-updates

# 更新单个技能
openclaw skills update weather

# 更新所有技能
openclaw skills update --all

# 回滚技能版本
openclaw skills rollback weather --version "1.1.0"
```

### 8.4 技能开发基础

#### 创建新技能
```bash
# 创建技能模板
openclaw skills create my-new-skill

# 进入技能目录
cd ~/.openclaw/skills/my-new-skill

# 编辑技能文件
vim SKILL.md
```

#### 技能文件结构示例
**SKILL.md**
```markdown
# 我的新技能

## 描述
这是一个示例技能，用于演示技能开发。

## 工具
- my_tool: 执行特定功能

## 使用方法
```bash
openclaw skills run my-new-skill --option value
```

## 配置
需要设置以下环境变量：
- API_KEY: 服务API密钥
- ENDPOINT: 服务端点
```

**package.json**
```json
{
  "name": "my-new-skill",
  "version": "1.0.0",
  "description": "我的新技能",
  "main": "src/index.js",
  "tools": {
    "my_tool": {
      "description": "我的工具描述",
      "parameters": {
        "param1": {
          "type": "string",
          "description": "参数1说明"
        }
      }
    }
  }
}
```

---

## 9. 工具(Tools)使用指南

### 9.1 工具系统概述

#### 工具分类
1. **文件工具**：read, write, edit, exec
2. **网络工具**：web_search, web_fetch, browser
3. **通信工具**：message, feishu_chat
4. **系统工具**：nodes, canvas, cron
5. **媒体工具**：image, tts, image_generate
6. **管理工具**：gateway, sessions_spawn, subagents

#### 工具调用机制
```
用户请求 → 代理分析 → 选择工具 → 准备参数 → 执行工具 → 返回结果 → 格式化输出
```

### 9.2 核心工具详解

#### 文件工具 (read/write/edit)
```bash
# 读取文件
openclaw tools run read --path "/path/to/file.txt"

# 写入文件
openclaw tools run write --path "newfile.txt" --content "文件内容"

# 编辑文件
openclaw tools run edit --path "file.txt" --old "旧内容" --new "新内容"

# 执行命令
openclaw tools run exec --command "ls -la"
```

#### 网络工具
```bash
# 网页搜索
openclaw tools run web_search --query "OpenClaw 教程"

# 获取网页内容
openclaw tools run web_fetch --url "https://example.com"

# 浏览器控制
openclaw tools run browser --action "open" --url "https://google.com"
```

#### 消息工具
```bash
# 发送消息
openclaw tools run message --action "send" --to "user@example.com" --message "你好"

# 读取消息
openclaw tools run message --action "read" --limit 10

# 消息反应
openclaw tools run message --action "react" --message-id "123" --emoji "👍"
```

### 9.3 工具权限管理

#### 查看工具权限
```bash
# 列出所有可用工具
openclaw tools list

# 查看工具详情
openclaw tools describe read

# 查看工具权限
openclaw tools permissions
```

#### 配置工具权限
```bash
# 启用/禁用工具
openclaw config set tools.exec.enabled true
openclaw config set tools.message.enabled false

# 设置权限级别
openclaw config set tools.exec.security "allowlist"
openclaw config set tools.write.security "restricted"

# 配置允许列表
openclaw config set tools.exec.allowlist '["ls", "pwd", "date"]'
```

#### 工具使用统计
```bash
# 查看工具使用情况
openclaw tools stats

# 查看最常用工具
openclaw tools stats --top 10

# 查看工具错误统计
openclaw tools stats --errors
```

### 9.4 工具开发

#### 创建自定义工具
1. **创建工具定义文件**
```json
{
  "name": "my_custom_tool",
  "description": "我的自定义工具",
  "parameters": {
    "input": {
      "type": "string",
      "description": "输入参数"
    }
  },
  "handler": "async (params) => { return { result: '处理完成' }; }"
}
```

2. **注册工具**
```bash
# 注册新工具
openclaw tools register --file my-tool.json

# 测试工具
openclaw tools test my_custom_tool --input "测试数据"

# 卸载工具
openclaw tools unregister my_custom_tool
```

---

## 10. 渠道(Channels)配置

### 10.1 支持的通信渠道

#### 即时通讯平台
- **Telegram**：机器人集成
- **Discord**：机器人集成
- **WhatsApp**：Web 版本集成
- **飞书**：企业版集成
- **Signal**：个人消息
- **iMessage**：苹果消息

#### 协作平台
- **Slack**：工作区集成
- **Microsoft Teams**：团队协作
- **Google Chat**：Google Workspace

#### 其他渠道
- **IRC**：传统聊天协议
- **Email**：电子邮件
- **Webhook**：HTTP 回调

### 10.2 渠道配置步骤

#### Telegram 配置
```bash
# 启动 Telegram 配置
openclaw channels login telegram

# 使用机器人令牌
openclaw config set channels.telegram.botToken "YOUR_BOT_TOKEN"

# 启用渠道
openclaw config set channels.telegram.enabled true

# 测试连接
openclaw channels test telegram
```

#### Discord 配置
```bash
# 创建 Discord 机器人
# 1. 访问 https://discord.com/developers/applications
# 2. 创建新应用
# 3. 获取机器人令牌

# 配置 Discord
openclaw config set channels.discord.botToken "YOUR_DISCORD_TOKEN"
openclaw config set channels.discord.enabled true

# 设置权限
openclaw config set channels.discord.permissions "534723950656"
```

#### 飞书配置
```bash
# 飞书企业自建应用配置
openclaw config set channels.feishu.appId "your-app-id"
openclaw config set channels.feishu.appSecret "your-app-secret"
openclaw config set channels.feishu.encryptKey "your-encrypt-key"
openclaw config set channels.feishu.verificationToken "your-verification-token"

# 启用飞书
openclaw config set channels.feishu.enabled true
```

### 10.3 渠道管理命令

#### 查看渠道状态
```bash
# 列出所有渠道
openclaw channels list

# 查看渠道详情
openclaw channels describe telegram

# 检查渠道连接状态
openclaw channels status

# 查看渠道日志
openclaw channels logs telegram
```

#### 渠道操作
```bash
# 启动渠道
openclaw channels start telegram

# 停止渠道
openclaw channels stop telegram

# 重启渠道
openclaw channels restart telegram

# 重新登录
openclaw channels relogin telegram
```

#### 渠道测试
```bash
# 测试消息发送
openclaw channels test telegram --to "@username" --message "测试消息"

# 测试接收功能
openclaw channels test telegram --receive

# 完整功能测试
openclaw channels test telegram --full
```

### 10.4 多渠道管理

#### 统一消息发送
```bash
# 向多个渠道发送相同消息
openclaw message broadcast \
  --channels "telegram,discord" \
  --message "重要通知：系统维护中"

# 定时广播
openclaw cron add --name "daily-report" \
  --schedule "0 9 * * *" \
  --command 'openclaw message broadcast --channels "telegram,discord" --message "每日报告已生成"'
```

#### 渠道路由规则
```bash
# 配置消息路由
openclaw config set routing.rules '[{
  "pattern": "紧急.*",
  "channels": ["telegram", "discord"]
}, {
  "pattern": "报告.*",
  "channels": ["feishu"]
}]'

# 设置默认渠道
openclaw config set routing.defaultChannel "telegram"
```

#### 渠道监控
```bash
# 监控渠道健康状态
openclaw channels monitor

# 设置监控告警
openclaw config set monitoring.alerts.channelDown true
openclaw config set monitoring.alerts.channelDownThreshold 300

# 查看渠道统计
openclaw channels stats --period "7d"
```

---

## 11. 消息发送与管理

### 11.1 消息发送基础

#### 基本消息发送
```bash
# 发送文本消息
openclaw message send --to "+1234567890" --message "你好，世界！"

# 发送到特定渠道
openclaw message send --channel telegram --to "@username" --message "Telegram消息"

# 发送带格式的消息
openclaw message send --to "user@example.com" \
  --message "**重要通知**\n\n请查看以下内容：\n- 项目更新\n- 会议安排"
```

#### 消息选项
```bash
# 发送静默消息（不通知）
openclaw message send --to "@username" --message "静默消息" --silent

# 引用回复
openclaw message send --to "@username" --message "回复消息" --reply-to "message_id"

# 发送语音消息
openclaw message send --to "@username" --message "文字转语音" --as-voice

# 发送带效果的消息
openclaw message send --to "@username" --message "特效消息" --effect "invisible-ink"
```

### 11.2 媒体消息发送

#### 发送图片
```bash
# 发送本地图片
openclaw message send --to "@username" \
  --media "/path/to/image.jpg" \
  --caption "图片说明"

# 发送网络图片
openclaw message send --to "@username" \
  --media "https://example.com/image.png" \
  --caption "网络图片"

# 发送多张图片
openclaw message send --to "@username" \
  --media "/path/to/img1.jpg,/path/to/img2.jpg" \
  --caption "多图展示"
```

#### 发送文件
```bash
# 发送文档
openclaw message send --to "@username" \
  --media "/path/to/document.pdf" \
  --caption "项目文档" \
  --as-document

# 发送视频
openclaw message send --to "@username" \
  --media "/path/to/video.mp4" \
  --caption "演示视频"

# 发送音频
openclaw message send --to "@username" \
  --media "/path/to/audio.mp3" \
  --caption "录音文件"
```

#### 发送位置和联系人
```bash
# 发送位置
openclaw message send --to "@username" \
  --location "40.7128,-74.0060" \
  --caption "纽约市位置"

# 发送联系人
openclaw message send --to "@username" \
  --contact "+1234567890" \
  --name "张三"
```

### 11.3 消息管理

#### 读取消息
```bash
# 读取最新消息
openclaw message read --limit 10

# 读取特定聊天
openclaw message read --chat "chat_id" --limit 20

# 读取时间范围
openclaw message read --after "2024-01-01" --before "2024-01-31"

# 搜索消息
openclaw message read --query "关键词" --limit 50
```

#### 消息操作
```bash
# 编辑消息
openclaw message edit --message-id "msg123" --message "更新后的内容"

# 删除消息
openclaw message delete --message-id "msg123"

# 置顶消息
openclaw message pin --message-id "msg123"

# 取消置顶
openclaw message unpin --message-id "msg123"
```

#### 消息反应
```bash
# 添加反应
openclaw message react --message-id "msg123" --emoji "👍"

# 移除反应
openclaw message react --message-id "msg123" --emoji "👍" --remove

# 查看反应
openclaw message reactions --message-id "msg123"
```

### 11.4 高级消息功能

#### 消息模板
```bash
# 定义消息模板
openclaw config set templates.daily_report '
**每日报告** {{date}}
- 完成任务：{{completed}}
- 进行中：{{in_progress}}
- 问题：{{issues}}
'

# 使用模板发送
openclaw message send --to "@manager" \
  --template "daily_report" \
  --vars '{"date": "2024-01-15", "completed": 5, "in_progress": 3, "issues": 1}'
```

#### 消息调度
```bash
# 定时发送消息
openclaw cron add --name "morning-greeting" \
  --schedule "0 9 * * *" \
  --command 'openclaw message send --to "@team" --message "早上好！新的一天开始了！"'

# 延迟发送
openclaw message send --to "@user" \
  --message "提醒消息" \
  --delay "2h"

# 重复发送
openclaw message send --to "@user" \
  --message "每日提醒" \
  --repeat "daily" \
  --end "2024-12-31"
```

#### 消息自动化
```bash
# 自动回复规则
openclaw config set autoReply.rules '[{
  "pattern": "你好|hello|hi",
  "response": "你好！我是OpenClaw助手，有什么可以帮您？"
}, {
  "pattern": "时间|几点",
  "response": "当前时间是 {{current_time}}"
}]'

# 启用自动回复
openclaw config set autoReply.enabled true
```

---

## 12. 群组与联系人管理

### 12.1 联系人管理

#### 查看联系人
```bash
# 列出所有联系人
openclaw directory contacts

# 搜索联系人
openclaw directory contacts --search "张三"

# 查看联系人详情
openclaw directory contact --id "contact_id"

# 导出联系人
openclaw directory contacts --export contacts.csv
```

#### 联系人操作
```bash
# 添加联系人
openclaw directory contact-add --name "李四" --phone "+1234567890"

# 更新联系人
openclaw directory contact-update --id "contact_id" --name "新名字"

# 删除联系人
openclaw directory contact-delete --id "contact_id"

# 导入联系人
openclaw directory contacts --import contacts.csv
```

### 12.2 群组管理

#### 查看群组
```bash
# 列出所有群组
openclaw directory groups

# 查看群组成员
openclaw directory group-members --group "group_id"

# 查看群组详情
openclaw directory group--id "group_id"

# 搜索群组
openclaw directory groups --search "项目"
```

#### 群组操作
```bash
# 创建群组
openclaw directory group-create --name "项目团队" --members "user1,user2"

# 添加成员
openclaw directory group-add-member --group "group_id" --member "user3"

# 移除成员
openclaw directory group-remove-member --group "group_id" --member "user1"

# 更新群组信息
openclaw directory group-update --id "group_id" --name "新群组名" --description "新描述"
```

### 12.3 聊天管理

#### 查看聊天列表
```bash
# 列出所有聊天
openclaw directory chats

# 查看聊天详情
openclaw directory chat --id "chat_id"

# 查看聊天历史
openclaw directory chat-history --chat "chat_id" --limit 50
```

#### 聊天操作
```bash
# 创建新聊天
openclaw directory chat-create --type "private" --participants "user1,user2"

# 归档聊天
openclaw directory chat-archive --chat "chat_id"

# 取消归档
openclaw directory chat-unarchive --chat "chat_id"

# 删除聊天
openclaw directory chat-delete --chat "chat_id"
```

---

## 13. 定时任务(Cron)系统

### 13.1 Cron 系统基础

#### 什么是 Cron？
Cron 是 OpenClaw 内置的定时任务调度系统，允许您：
- 定时执行命令和脚本
- 定期发送消息和通知
- 自动化重复性任务
- 监控系统状态

#### Cron 表达式格式
OpenClaw 支持标准的 Cron 表达式：
```
*    *    *    *    *
┬    ┬    ┬    ┬    ┬
│    │    │    │    │
│    │    │    │    └── 星期几 (0-7, 0和7都表示周日)
│    │    │    └───── 月份 (1-12)
│    │    └────────── 日期 (1-31)
│    └─────────────── 小时 (0-23)
└──────────────────── 分钟 (0-59)
```

### 13.2 Cron 任务管理

#### 查看 Cron 任务
```bash
# 列出所有 Cron 任务
openclaw cron list

# 查看任务详情
openclaw cron describe <job-id>

# 查看任务运行历史
openclaw cron runs <job-id>

# 查看任务状态
openclaw cron status
```

#### 创建 Cron 任务
```bash
# 创建简单定时任务
openclaw cron add --name "每日问候" \
  --schedule "0 9 * * *" \
  --command 'openclaw message send --to "@team" --message "早上好！"'

# 创建复杂定时任务
openclaw cron add --name "系统健康检查" \
  --schedule "*/30 * * * *" \
  --command 'openclaw health | openclaw message send --to "@admin" --message "系统状态报告"'

# 创建一次性任务
openclaw cron add --name "备份任务" \
  --schedule "at 2024-12-31T23:59:59" \
  --command 'openclaw backup create'
```

#### Cron 任务操作
```bash
# 立即运行任务
openclaw cron run <job-id>

# 暂停任务
openclaw cron pause <job-id>

# 恢复任务
openclaw cron resume <job-id>

# 更新任务
openclaw cron update <job-id> --schedule "0 10 * * *"

# 删除任务
openclaw cron remove <job-id>
```

### 13.3 高级 Cron 功能

#### 条件执行
```bash
# 只在工作日执行
openclaw cron add --name "工作日报告" \
  --schedule "0 18 * * 1-5" \
  --command 'openclaw message send --to "@manager" --message "工作日报告"'

# 每月第一天执行
openclaw cron add --name "月报" \
  --schedule "0 9 1 * *" \
  --command 'openclaw message send --to "@finance" --message "月度财务报告"'

# 每小时执行但跳过夜间
openclaw cron add --name "白天监控" \
  --schedule "0 8-20 * * *" \
  --command 'openclaw system monitor'
```

#### 任务依赖
```bash
# 创建任务链
openclaw cron add --name "数据备份" \
  --schedule "0 2 * * *" \
  --command 'openclaw backup create'

openclaw cron add --name "备份验证" \
  --schedule "0 3 * * *" \
  --command 'openclaw backup verify' \
  --depends-on "数据备份"
```

#### 错误处理和重试
```bash
# 配置重试机制
openclaw cron add --name "重要任务" \
  --schedule "0 * * * *" \
  --command 'openclaw system critical-task' \
  --retry 3 \
  --retry-delay "5m"

# 设置超时
openclaw cron add --name "长时间任务" \
  --schedule "0 0 * * *" \
  --command 'openclaw system long-task' \
  --timeout "1h"
```

### 13.4 Cron 监控和日志

#### 监控 Cron 任务
```bash
# 查看任务执行状态
openclaw cron monitor

# 查看失败任务
openclaw cron list --failed

# 查看即将执行的任务
openclaw cron list --upcoming

# 查看任务统计
openclaw cron stats
```

#### Cron 日志管理
```bash
# 查看任务日志
openclaw cron logs <job-id>

# 查看最近执行日志
openclaw cron logs --recent 10

# 导出任务日志
openclaw cron logs <job-id> --export logs.json

# 清理旧日志
openclaw cron logs --cleanup --older-than "30d"
```

#### 告警和通知
```bash
# 任务失败时发送通知
openclaw cron add --name "监控任务" \
  --schedule "*/5 * * * *" \
  --command 'openclaw system check' \
  --on-failure 'openclaw message send --to "@admin" --message "监控任务失败！"'

# 任务成功时发送报告
openclaw cron add --name "日报生成" \
  --schedule "0 17 * * *" \
  --command 'openclaw report generate' \
  --on-success 'openclaw message send --to "@team" --message "日报已生成"'
```

---

## 14. 节点(Nodes)管理

### 14.1 节点系统概述

#### 什么是节点？
节点是 OpenClaw 的远程设备代理，允许您：
- 控制远程设备（手机、平板、电脑）
- 访问设备摄像头和传感器
- 执行设备上的命令
- 监控设备状态

#### 节点类型
1. **Android 节点**：Android 设备
2. **iOS 节点**：iPhone 和 iPad
3. **macOS 节点**：Mac 电脑
4. **Windows 节点**：Windows 电脑
5. **Linux 节点**：Linux 服务器

### 14.2 节点配对和管理

#### 查看节点状态
```bash
# 列出所有节点
openclaw nodes list

# 查看节点详情
openclaw nodes describe <node-id>

# 查看节点健康状态
openclaw nodes health

# 查看待处理配对请求
openclaw nodes pending
```

#### 节点配对
```bash
# 生成配对二维码
openclaw qr

# 批准配对请求
openclaw nodes approve <request-id>

# 拒绝配对请求
openclaw nodes reject <request-id>

# 手动配对
openclaw nodes pair --code "SETUP-CODE"
```

#### 节点操作
```bash
# 连接节点
openclaw nodes connect <node-id>

# 断开节点
openclaw nodes disconnect <node-id>

# 重启节点服务
openclaw nodes restart <node-id>

# 移除节点
openclaw nodes remove <node-id>
```

### 14.3 节点功能

#### 设备控制
```bash
# 获取设备信息
openclaw nodes device-info <node-id>

# 获取设备状态
openclaw nodes device-status <node-id>

# 检查设备权限
openclaw nodes device-permissions <node-id>

# 获取设备健康报告
openclaw nodes device-health <node-id>
```

#### 摄像头功能
```bash
# 拍摄照片
openclaw nodes camera-snap <node-id> --facing "back"

# 录制视频
openclaw nodes camera-clip <node-id> --duration "10s"

# 列出摄像头
openclaw nodes camera-list <node-id>

# 获取最新照片
openclaw nodes photos-latest <node-id> --limit 5
```

#### 屏幕功能
```bash
# 屏幕截图
openclaw nodes screen-record <node-id> --duration "5s"

# 录制屏幕
openclaw nodes screen-record <node-id> --duration "30s" --include-audio

# 获取屏幕信息
openclaw nodes screen-info <node-id>
```

#### 位置和传感器
```bash
# 获取设备位置
openclaw nodes location-get <node-id>

# 获取精确位置
openclaw nodes location-get <node-id> --desired-accuracy "precise"

# 获取传感器数据
openclaw nodes sensors <node-id>
```

### 14.4 节点通知

#### 发送通知
```bash
# 发送简单通知
openclaw nodes notify <node-id> --title "提醒" --body "会议即将开始"

# 发送重要通知
openclaw nodes notify <node-id> \
  --title "紧急" \
  --body "系统警报" \
  --priority "timeSensitive" \
  --sound "default"

# 发送带操作的通知
openclaw nodes notify <node-id> \
  --title "消息" \
  --body "您有新消息" \
  --actions '["回复", "忽略"]'
```

#### 管理通知
```bash
# 列出通知
openclaw nodes notifications-list <node-id>

# 打开通知
openclaw nodes notifications-action <node-id> --action "open" --key "notification-key"

# 关闭通知
openclaw nodes notifications-action <node-id> --action "dismiss" --key "notification-key"

# 回复通知
openclaw nodes notifications-action <node-id> \
  --action "reply" \
  --key "notification-key" \
  --reply-text "收到，谢谢"
```

### 14.5 节点命令执行

#### 在节点上执行命令
```bash
# 执行简单命令
openclaw nodes run <node-id> --command "ls -la"

# 执行复杂命令
openclaw nodes run <node-id> \
  --command "python" \
  --args '["script.py", "--input", "data.txt"]' \
  --cwd "/path/to/workspace"

# 执行带环境的命令
openclaw nodes run <node-id> \
  --command "node" \
  --args '["app.js"]' \
  --env '{"NODE_ENV":"production","API_KEY":"secret"}'
```

#### 节点脚本
```bash
# 上传并执行脚本
openclaw nodes invoke <node-id> \
  --command "script.sh" \
  --params '{"param1":"value1","param2":"value2"}'

# 执行远程脚本
openclaw nodes invoke <node-id> \
  --command "remote-task" \
  --params '{"url":"https://example.com/script","timeout":30000}'
```

---

## 15. 浏览器控制

### 15.1 浏览器系统概述

#### 支持的浏览器
- **Chrome**：Google Chrome
- **Chromium**：开源 Chromium
- **Edge**：Microsoft Edge（Chromium 版）
- **Brave**：Brave 浏览器

#### 浏览器控制功能
- 网页导航和浏览
- 表单填写和提交
- 截图和PDF生成
- JavaScript执行
- 元素交互和自动化

### 15.2 浏览器管理

#### 查看浏览器状态
```bash
# 查看浏览器状态
openclaw browser status

# 列出浏览器标签页
openclaw browser tabs

# 查看浏览器配置
openclaw browser profiles
```

#### 浏览器操作
```bash
# 启动浏览器
openclaw browser start

# 停止浏览器
openclaw browser stop

# 重启浏览器
openclaw browser restart

# 清理浏览器数据
openclaw browser cleanup
```

### 15.3 网页导航和控制

#### 基本导航
```bash
# 打开网页
openclaw browser open --url "https://google.com"

# 导航到新页面
openclaw browser navigate --url "https://example.com"

# 返回上一页
openclaw browser navigate --back

# 前进到下一页
openclaw browser navigate --forward

# 刷新页面
openclaw browser navigate --refresh
```

#### 标签页管理
```bash
# 新建标签页
openclaw browser open --url "https://newtab.com" --new-tab

# 切换标签页
openclaw browser focus --tab-id "tab-123"

# 关闭标签页
openclaw browser close --tab-id "tab-123"

# 获取当前标签页
openclaw browser tabs --current
```

### 15.4 网页交互

#### 元素操作
```bash
# 点击元素
openclaw browser act --kind "click" --selector "button.submit"

# 输入文本
openclaw browser act --kind "type" --selector "input.name" --text "张三"

# 选择下拉选项
openclaw browser act --kind "select" --selector "select.country" --values '["中国"]'

# 填写表单
openclaw browser act --kind "fill" --selector "form.login" \
  --fields '[{"selector":"input.email","value":"user@example.com"},{"selector":"input.password","value":"secret"}]'
```

#### 页面操作
```bash
# 滚动页面
openclaw browser act --kind "scroll" --selector "div.content"

# 等待元素出现
openclaw browser act --kind "wait" --selector "div.loaded" --timeMs 5000

# 执行JavaScript
openclaw browser act --kind "evaluate" \
  --fn "() => document.title"

# 调整窗口大小
openclaw browser act --kind "resize" --width 1280 --height 720
```

### 15.5 截图和内容获取

#### 页面截图
```bash
# 截取当前页面
openclaw browser screenshot

# 截取完整页面
openclaw browser screenshot --full-page

# 截取特定区域
openclaw browser screenshot --selector "div.content"

# 保存截图
openclaw browser screenshot --output "screenshot.png"
```

#### 页面快照
```bash
# 获取页面结构快照
openclaw browser snapshot

# 获取可交互快照
openclaw browser snapshot --interactive

# 获取简洁快照
openclaw browser snapshot --compact

# 获取带引用的快照
openclaw browser snapshot --refs "aria"
```

#### 内容提取
```bash
# 获取页面文本
openclaw browser console --command "document.body.innerText"

# 获取页面HTML
openclaw browser console --command "document.documentElement.outerHTML"

# 获取页面PDF
openclaw browser pdf --output "page.pdf"
```

### 15.6 文件上传和对话框

#### 文件上传
```bash
# 上传文件
openclaw browser upload \
  --input-ref "file-input" \
  --paths '["/path/to/file1.pdf","/path/to/file2.jpg"]'

# 多文件上传
openclaw browser upload \
  --selector "input[type=file]" \
  --paths '["file1.txt","file2.txt"]'
```

#### 对话框处理
```bash
# 接受对话框
openclaw browser dialog --accept

# 拒绝对话框
openclaw browser dialog --accept false

# 输入对话框文本
openclaw browser dialog --accept --prompt-text "确认信息"
```

---

## 16. 安全与权限管理

### 16.1 安全配置

#### 基本安全设置
```bash
# 查看安全配置
openclaw security config

# 运行安全审计
openclaw security audit

# 深度安全审计
openclaw security audit --deep

# 修复安全问题
openclaw security fix
```

#### 认证和授权
```bash
# 配置认证令牌
openclaw config set gateway.auth.token $(openssl rand -hex 32)

# 设置访问控制
openclaw config set gateway.auth.rateLimit.maxAttempts 10
openclaw config set gateway.auth.rateLimit.windowMs 60000
openclaw config set gateway.auth.rateLimit.lockoutMs 300000

# 配置IP白名单
openclaw config set gateway.auth.allowedIPs '["192.168.1.0/24","10.0.0.1"]'
```

#### TLS/SSL配置
```bash
# 启用HTTPS
openclaw config set gateway.tls.enabled true

# 配置证书
openclaw config set gateway.t